﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace POSApi.Entities
{
    public class SysForm
    {
        public Int32 Id { get; set; }
        public String Form { get; set; }
        public String FormDescription { get; set; }
    }
}