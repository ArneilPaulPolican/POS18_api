﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace POSApi
{
    public class Settings
    {
        public static String kitchenReportDefaultPrinterName = "EPSON TM-U220 Receipt";
    }
}